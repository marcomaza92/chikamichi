<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h1>Transactions CRUD</h1>
            </div>
        </div>
    </div>

    <div class="pull-right">
        <a class="btn btn-success" href="<?php echo e(route('auth.index')); ?>"> View Demo</a>
    </div>


    <!-- <?php echo $tnxs->render(); ?> -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('tnxs.container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>