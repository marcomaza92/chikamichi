@extends('tnxs.container')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h1>Transactions CRUD</h1>
            </div>
        </div>
    </div>

    <div class="pull-right">
        <a class="btn btn-success" href="{{ route('auth.index') }}"> View Demo</a>
    </div>


    <!-- {!! $tnxs->render() !!} -->

@endsection
